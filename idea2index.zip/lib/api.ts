import type { IndexData, Holding } from "@/app/page"

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || ""

export async function generateIndex(prompt: string): Promise<IndexData> {
  const response = await fetch(`${API_BASE_URL}/api/generate-index`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ prompt }),
  })

  if (!response.ok) {
    throw new Error("Failed to generate index")
  }

  return response.json()
}

export async function updateHoldings(holdings: Holding[]): Promise<{ message: string; holdings: Holding[] }> {
  const response = await fetch(`${API_BASE_URL}/api/update-holdings`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(holdings),
  })

  if (!response.ok) {
    const error = await response.json()
    throw new Error(error.error || "Failed to update holdings")
  }

  return response.json()
}

export async function refineIndex(action: "broaden" | "narrow", indexData: IndexData): Promise<IndexData> {
  // Placeholder for future AI refinement API
  const response = await fetch(`${API_BASE_URL}/api/refine-index`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ action, indexData }),
  })

  if (!response.ok) {
    throw new Error("Failed to refine index")
  }

  return response.json()
}
