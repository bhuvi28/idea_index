export function generateMockPerformanceData(months = 12) {
  const endDate = new Date()
  const startDate = new Date()
  startDate.setMonth(endDate.getMonth() - months)

  const dates: string[] = []
  const indexValues: number[] = []
  const benchmarkValues: number[] = []

  // Generate business days only
  const currentDate = new Date(startDate)
  let indexValue = 100
  let benchmarkValue = 100

  while (currentDate <= endDate) {
    // Skip weekends
    if (currentDate.getDay() !== 0 && currentDate.getDay() !== 6) {
      dates.push(currentDate.toISOString().split("T")[0])

      // Generate more realistic performance data with some correlation
      const indexReturn = (Math.random() - 0.48) * 0.02 // Slightly positive bias
      const benchmarkReturn = (Math.random() - 0.49) * 0.015 // Slightly less volatile

      indexValue *= 1 + indexReturn
      benchmarkValue *= 1 + benchmarkReturn

      indexValues.push(Number(indexValue.toFixed(2)))
      benchmarkValues.push(Number(benchmarkValue.toFixed(2)))
    }

    currentDate.setDate(currentDate.getDate() + 1)
  }

  return {
    dates,
    index_values: indexValues,
    benchmark_values: benchmarkValues,
  }
}

export function generateMockStats(performanceData: { index_values: number[]; benchmark_values: number[] }) {
  const indexReturns = performanceData.index_values.map((value, i) =>
    i === 0 ? 0 : (value - performanceData.index_values[i - 1]) / performanceData.index_values[i - 1],
  )

  const totalReturn = ((performanceData.index_values[performanceData.index_values.length - 1] - 100) / 100) * 100

  // Calculate max drawdown
  let maxDrawdown = 0
  let peak = performanceData.index_values[0]

  for (const value of performanceData.index_values) {
    if (value > peak) peak = value
    const drawdown = ((value - peak) / peak) * 100
    if (drawdown < maxDrawdown) maxDrawdown = drawdown
  }

  // Simple Sharpe ratio approximation
  const avgReturn = indexReturns.reduce((sum, ret) => sum + ret, 0) / indexReturns.length
  const volatility = Math.sqrt(
    indexReturns.reduce((sum, ret) => sum + Math.pow(ret - avgReturn, 2), 0) / indexReturns.length,
  )
  const sharpeRatio = (avgReturn / volatility) * Math.sqrt(252) // Annualized

  return {
    total_return: Number(totalReturn.toFixed(1)),
    max_drawdown: Number(maxDrawdown.toFixed(1)),
    sharpe_ratio: Number(sharpeRatio.toFixed(2)),
  }
}

export function generateBenchmarkStats(performanceData: { benchmark_values: number[] }) {
  const benchmarkReturns = performanceData.benchmark_values.map((value, i) =>
    i === 0 ? 0 : (value - performanceData.benchmark_values[i - 1]) / performanceData.benchmark_values[i - 1],
  )

  const totalReturn =
    ((performanceData.benchmark_values[performanceData.benchmark_values.length - 1] - 100) / 100) * 100

  // Calculate max drawdown for benchmark
  let maxDrawdown = 0
  let peak = performanceData.benchmark_values[0]

  for (const value of performanceData.benchmark_values) {
    if (value > peak) peak = value
    const drawdown = ((value - peak) / peak) * 100
    if (drawdown < maxDrawdown) maxDrawdown = drawdown
  }

  // Simple Sharpe ratio approximation for benchmark
  const avgReturn = benchmarkReturns.reduce((sum, ret) => sum + ret, 0) / benchmarkReturns.length
  const volatility = Math.sqrt(
    benchmarkReturns.reduce((sum, ret) => sum + Math.pow(ret - avgReturn, 2), 0) / benchmarkReturns.length,
  )
  const sharpeRatio = (avgReturn / volatility) * Math.sqrt(252) // Annualized

  return {
    total_return: Number(totalReturn.toFixed(1)),
    max_drawdown: Number(maxDrawdown.toFixed(1)),
    sharpe_ratio: Number(sharpeRatio.toFixed(2)),
  }
}
