from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Any
import random
import json

app = FastAPI(title="Idea2Index API", version="1.0.0")

# Enable CORS for frontend communication
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class IndexRequest(BaseModel):
    prompt: str

class Holding(BaseModel):
    ticker: str
    security_name: str
    country: str
    sector: str
    market_cap: str
    relevance: str
    selection_rationale: str
    weight: float

class IndexResponse(BaseModel):
    index_name: str
    holdings: List[Holding]
    performance_data: Dict[str, Any]
    stats: Dict[str, float]
    scores: Dict[str, Dict[str, Any]]

# Mock data generators - Plug real Python function/API here
def generate_mock_holdings(prompt: str) -> List[Holding]:
    """Generate mock holdings based on prompt - Plug real AI function here"""
    
    # Sample holdings pool for different themes
    tech_holdings = [
        {"ticker": "AAPL", "name": "Apple Inc.", "sector": "Technology", "rationale": "Leading consumer electronics and services"},
        {"ticker": "MSFT", "name": "Microsoft Corporation", "sector": "Technology", "rationale": "Dominant cloud computing platform"},
        {"ticker": "GOOGL", "name": "Alphabet Inc.", "sector": "Technology", "rationale": "Search engine and AI innovation leader"},
        {"ticker": "NVDA", "name": "NVIDIA Corporation", "sector": "Technology", "rationale": "AI chip manufacturing leader"},
        {"ticker": "TSLA", "name": "Tesla Inc.", "sector": "Consumer Discretionary", "rationale": "Electric vehicle and clean energy pioneer"},
    ]
    
    green_holdings = [
        {"ticker": "NEE", "name": "NextEra Energy", "sector": "Utilities", "rationale": "Renewable energy infrastructure leader"},
        {"ticker": "ENPH", "name": "Enphase Energy", "sector": "Technology", "rationale": "Solar energy systems innovation"},
        {"ticker": "TSLA", "name": "Tesla Inc.", "sector": "Consumer Discretionary", "rationale": "Electric vehicle pioneer"},
        {"ticker": "BEP", "name": "Brookfield Renewable", "sector": "Utilities", "rationale": "Global renewable power portfolio"},
        {"ticker": "ICLN", "name": "iShares Clean Energy ETF", "sector": "Energy", "rationale": "Diversified clean energy exposure"},
    ]
    
    # Simple keyword matching - Plug real NLP/AI here
    if any(word in prompt.lower() for word in ["tech", "technology", "ai", "artificial intelligence"]):
        base_holdings = tech_holdings
    elif any(word in prompt.lower() for word in ["green", "clean", "renewable", "sustainable", "esg"]):
        base_holdings = green_holdings
    else:
        base_holdings = tech_holdings  # Default
    
    # Generate random weights that sum to 100%
    weights = [random.uniform(10, 30) for _ in range(len(base_holdings))]
    total_weight = sum(weights)
    normalized_weights = [round((w / total_weight) * 100, 2) for w in weights]
    
    # Ensure weights sum to exactly 100%
    diff = 100.0 - sum(normalized_weights)
    normalized_weights[0] += diff
    
    holdings = []
    for i, holding in enumerate(base_holdings):
        holdings.append(Holding(
            ticker=holding["ticker"],
            security_name=holding["name"],
            country="United States",
            sector=holding["sector"],
            market_cap=random.choice(["Large Cap", "Mid Cap", "Small Cap"]),
            relevance="High",
            selection_rationale=holding["rationale"],
            weight=normalized_weights[i]
        ))
    
    return holdings

def generate_mock_performance_data() -> Dict[str, Any]:
    """Generate mock performance data - Plug real market data API here"""
    
    # Generate 252 trading days of mock data
    dates = []
    index_values = []
    benchmark_values = []
    
    base_date = "2024-01-01"
    index_value = 100.0
    benchmark_value = 100.0
    
    for i in range(252):
        # Mock daily returns
        index_return = random.normalvariate(0.0008, 0.015)  # ~20% annual return, 15% volatility
        benchmark_return = random.normalvariate(0.0005, 0.012)  # ~12% annual return, 12% volatility
        
        index_value *= (1 + index_return)
        benchmark_value *= (1 + benchmark_return)
        
        dates.append(f"2024-{(i//21)+1:02d}-{(i%21)+1:02d}")
        index_values.append(round(index_value, 2))
        benchmark_values.append(round(benchmark_value, 2))
    
    return {
        "dates": dates,
        "index_values": index_values,
        "benchmark_values": benchmark_values
    }

def generate_mock_stats() -> Dict[str, float]:
    """Generate mock performance statistics - Plug real calculation here"""
    return {
        "total_return": round(random.uniform(15.0, 25.0), 2),
        "max_drawdown": round(random.uniform(-8.0, -15.0), 2),
        "sharpe_ratio": round(random.uniform(1.2, 1.8), 2)
    }

def generate_mock_scores() -> Dict[str, Dict[str, Any]]:
    """Generate mock scoring data - Plug real analysis here"""
    return {
        "asset_score": {
            "score": random.randint(7, 9),
            "max_score": 10,
            "description": "Quality and fundamentals of underlying assets"
        },
        "returns_score": {
            "score": random.randint(6, 8),
            "max_score": 10,
            "description": "Historical and expected return performance"
        },
        "stability_score": {
            "score": random.randint(7, 9),
            "max_score": 10,
            "description": "Volatility and downside risk management"
        },
        "diversification_score": {
            "score": random.randint(5, 7),
            "max_score": 10,
            "description": "Portfolio concentration and correlation analysis"
        }
    }

@app.get("/")
async def root():
    return {"message": "Idea2Index API is running"}

@app.post("/generate-index", response_model=IndexResponse)
async def generate_index(request: IndexRequest):
    """Generate investment index from user prompt"""
    try:
        # Generate index name from prompt - Plug real NLP here
        index_name = f"{request.prompt.title()} Index"
        if len(index_name) > 50:
            index_name = index_name[:47] + "..."
        
        # Generate all components
        holdings = generate_mock_holdings(request.prompt)
        performance_data = generate_mock_performance_data()
        stats = generate_mock_stats()
        scores = generate_mock_scores()
        
        return IndexResponse(
            index_name=index_name,
            holdings=holdings,
            performance_data=performance_data,
            stats=stats,
            scores=scores
        )
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.put("/update-holdings")
async def update_holdings(holdings: List[Holding]):
    """Update portfolio holdings with weight validation"""
    try:
        # Validate weights sum to 100%
        total_weight = sum(holding.weight for holding in holdings)
        if abs(total_weight - 100.0) > 0.01:  # Allow small floating point errors
            raise HTTPException(
                status_code=400, 
                detail=f"Holdings weights must sum to 100%. Current sum: {total_weight}%"
            )
        
        # In real implementation, save to database here
        return {"message": "Holdings updated successfully", "holdings": holdings}
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
