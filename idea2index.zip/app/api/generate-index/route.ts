import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { prompt } = await request.json()

    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required" }, { status: 400 })
    }

    // In production, this would call the actual FastAPI backend
    // For now, we'll use the same mock logic as the Python backend

    // Mock data generators - Plug real Python function/API here
    const generateMockHoldings = (prompt: string) => {
      const techHoldings = [
        {
          ticker: "AAPL",
          name: "Apple Inc.",
          sector: "Technology",
          rationale: "Leading consumer electronics and services",
        },
        {
          ticker: "MSFT",
          name: "Microsoft Corporation",
          sector: "Technology",
          rationale: "Dominant cloud computing platform",
        },
        {
          ticker: "GOOGL",
          name: "Alphabet Inc.",
          sector: "Technology",
          rationale: "Search engine and AI innovation leader",
        },
        { ticker: "NVDA", name: "NVIDIA Corporation", sector: "Technology", rationale: "AI chip manufacturing leader" },
        {
          ticker: "TSLA",
          name: "Tesla Inc.",
          sector: "Consumer Discretionary",
          rationale: "Electric vehicle and clean energy pioneer",
        },
      ]

      const greenHoldings = [
        {
          ticker: "NEE",
          name: "NextEra Energy",
          sector: "Utilities",
          rationale: "Renewable energy infrastructure leader",
        },
        { ticker: "ENPH", name: "Enphase Energy", sector: "Technology", rationale: "Solar energy systems innovation" },
        { ticker: "TSLA", name: "Tesla Inc.", sector: "Consumer Discretionary", rationale: "Electric vehicle pioneer" },
        {
          ticker: "BEP",
          name: "Brookfield Renewable",
          sector: "Utilities",
          rationale: "Global renewable power portfolio",
        },
        {
          ticker: "ICLN",
          name: "iShares Clean Energy ETF",
          sector: "Energy",
          rationale: "Diversified clean energy exposure",
        },
      ]

      // Simple keyword matching - Plug real NLP/AI here
      let baseHoldings = techHoldings
      if (
        prompt.toLowerCase().includes("green") ||
        prompt.toLowerCase().includes("clean") ||
        prompt.toLowerCase().includes("renewable") ||
        prompt.toLowerCase().includes("sustainable") ||
        prompt.toLowerCase().includes("esg")
      ) {
        baseHoldings = greenHoldings
      }

      // Generate random weights that sum to 100%
      const weights = baseHoldings.map(() => Math.random() * 20 + 10)
      const totalWeight = weights.reduce((sum, w) => sum + w, 0)
      const normalizedWeights = weights.map((w) => Math.round((w / totalWeight) * 100 * 100) / 100)

      // Ensure weights sum to exactly 100%
      const diff = 100.0 - normalizedWeights.reduce((sum, w) => sum + w, 0)
      normalizedWeights[0] += diff

      return baseHoldings.map((holding, i) => ({
        ticker: holding.ticker,
        security_name: holding.name,
        country: "United States",
        sector: holding.sector,
        market_cap: ["Large Cap", "Mid Cap", "Small Cap"][Math.floor(Math.random() * 3)],
        relevance: "High",
        selection_rationale: holding.rationale,
        weight: normalizedWeights[i],
      }))
    }

    const generateMockPerformanceData = () => {
      const dates = []
      const indexValues = []
      const benchmarkValues = []

      let indexValue = 100.0
      let benchmarkValue = 100.0

      for (let i = 0; i < 252; i++) {
        const indexReturn = (Math.random() - 0.5) * 0.03 + 0.0008
        const benchmarkReturn = (Math.random() - 0.5) * 0.024 + 0.0005

        indexValue *= 1 + indexReturn
        benchmarkValue *= 1 + benchmarkReturn

        dates.push(`2024-${String(Math.floor(i / 21) + 1).padStart(2, "0")}-${String((i % 21) + 1).padStart(2, "0")}`)
        indexValues.push(Math.round(indexValue * 100) / 100)
        benchmarkValues.push(Math.round(benchmarkValue * 100) / 100)
      }

      return { dates, index_values: indexValues, benchmark_values: benchmarkValues }
    }

    const generateMockStats = () => ({
      total_return: Math.round((Math.random() * 10 + 15) * 100) / 100,
      max_drawdown: Math.round((Math.random() * -7 - 8) * 100) / 100,
      sharpe_ratio: Math.round((Math.random() * 0.6 + 1.2) * 100) / 100,
    })

    const generateMockScores = () => ({
      asset_score: {
        score: Math.floor(Math.random() * 3) + 7,
        max_score: 10,
        description: "Quality and fundamentals of underlying assets",
      },
      returns_score: {
        score: Math.floor(Math.random() * 3) + 6,
        max_score: 10,
        description: "Historical and expected return performance",
      },
      stability_score: {
        score: Math.floor(Math.random() * 3) + 7,
        max_score: 10,
        description: "Volatility and downside risk management",
      },
      diversification_score: {
        score: Math.floor(Math.random() * 3) + 5,
        max_score: 10,
        description: "Portfolio concentration and correlation analysis",
      },
    })

    // Generate index name from prompt - Plug real NLP here
    let indexName = `${prompt.charAt(0).toUpperCase() + prompt.slice(1)} Index`
    if (indexName.length > 50) {
      indexName = indexName.substring(0, 47) + "..."
    }

    const responseData = {
      index_name: indexName,
      holdings: generateMockHoldings(prompt),
      performance_data: generateMockPerformanceData(),
      stats: generateMockStats(),
      scores: generateMockScores(),
    }

    return NextResponse.json(responseData)
  } catch (error) {
    console.error("Error generating index:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
