"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

interface LandingPageProps {
  onGenerateIndex: (prompt: string) => void
  isLoading: boolean
}

const PROMPT_CHIPS = [
  "AI and Machine Learning Companies",
  "Sustainable Energy Portfolio",
  "Healthcare Innovation Index",
  "Emerging Markets Growth",
  "Dividend Aristocrats Fund",
  "Cybersecurity Leaders",
  "Cloud Computing Giants",
  "Electric Vehicle Revolution",
]

export default function LandingPage({ onGenerateIndex, isLoading }: LandingPageProps) {
  const [prompt, setPrompt] = useState("")
  const [currentChipIndex, setCurrentChipIndex] = useState(0)

  // Animate prompt chips
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentChipIndex((prev) => (prev + 1) % PROMPT_CHIPS.length)
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (prompt.trim() && !isLoading) {
      onGenerateIndex(prompt.trim())
    }
  }

  const handleChipClick = (chipText: string) => {
    if (!isLoading) {
      onGenerateIndex(chipText)
    }
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-48px)] px-4">
      <div className="w-full max-w-2xl space-y-8 text-center">
        {/* Main heading */}
        <div className="space-y-4">
          <h1 className="text-4xl md:text-6xl font-bold text-foreground">idea2index</h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-lg mx-auto">
            Transform your investment ideas into professionally weighted portfolios using AI
          </p>
        </div>

        {/* Main input form */}
        <Card className="p-6 bg-card border border-border">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="relative">
              <Input
                type="text"
                placeholder="Describe your investment idea..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="text-lg py-6 px-4 bg-background border-border focus:ring-2 focus:ring-primary"
                disabled={isLoading}
              />
            </div>
            <Button
              type="submit"
              size="lg"
              className="w-full py-6 text-lg font-medium"
              disabled={!prompt.trim() || isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Generating Index...
                </>
              ) : (
                "Generate Index"
              )}
            </Button>
          </form>
        </Card>

        {/* Animated prompt chips */}
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">Or try one of these ideas:</p>
          <div className="flex flex-wrap justify-center gap-2 min-h-[40px] items-center">
            {PROMPT_CHIPS.map((chip, index) => (
              <Button
                key={chip}
                variant="outline"
                size="sm"
                onClick={() => handleChipClick(chip)}
                disabled={isLoading}
                className={`transition-all duration-500 ${
                  index === currentChipIndex
                    ? "opacity-100 scale-105 border-primary text-primary"
                    : "opacity-60 hover:opacity-100"
                }`}
              >
                {chip}
              </Button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
